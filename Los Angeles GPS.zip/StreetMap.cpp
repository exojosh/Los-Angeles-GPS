#include "provided.h"
#include <string>
#include <vector>
#include <functional>
#include <fstream>
#include "ExpandableHashMap.h"
using namespace std;

unsigned int hasher(const GeoCoord& g)
{
    return std::hash<string>()(g.latitudeText + g.longitudeText);
}

template <typename T>
unsigned int hasher(const T thing)
{
    std::hash<T> hashed;
    return hashed;
}


template <typename T>
unsigned int hasher(const T& thing)
{
    unsigned int hash = std::hash<T>()(thing);
    return hash;
}


class StreetMapImpl
{
public:
    StreetMapImpl();
    ~StreetMapImpl();
    bool load(string mapFile);
    bool getSegmentsThatStartWith(const GeoCoord& gc, vector<StreetSegment>& segs) const;
private:
    ExpandableHashMap<GeoCoord, vector<StreetSegment>>* m_hash;

};

StreetMapImpl::StreetMapImpl()
{
    m_hash = new ExpandableHashMap<GeoCoord, vector<StreetSegment>>;
}

StreetMapImpl::~StreetMapImpl()
{
}

bool StreetMapImpl::load(string mapFile)
{
    ifstream line;
    line.open(mapFile.c_str());
    if (line.fail())
        return false;
    string str, streetname;
    GeoCoord* start;
    GeoCoord* end;
    vector<StreetSegment>* s;
    unsigned int num = 0, type = 0; //zero if street name, one if number of lines, and two if current line is a coordinate
    while (getline(line, str))
    {
        switch (type)
        {
        case 0:
            streetname = str;
            type = 1;
            break;
        case 1:
            num = stoi(str);
            type = 2;
            break;
        case 2:
            start = new GeoCoord(str.substr(0, 10), str.substr(11, 12));
            end = new GeoCoord(str.substr(24, 10), str.substr(35, 12));
            s = m_hash->find(*start);
            if (s == nullptr)
            {
                s = new vector<StreetSegment>;
                s->push_back(StreetSegment(*start, *end, streetname));
                m_hash->associate(*start, *s);
                delete s;
            }
            else
                s->push_back(StreetSegment(*start, *end, streetname));
            s = m_hash->find(*end);
            if (s == nullptr)
            {
                s = new vector<StreetSegment>;
                s->push_back(StreetSegment(*end, *start, streetname));
                m_hash->associate(*end, *s);
                delete s;
            }
            else
                s->push_back(StreetSegment(*end, *start, streetname));
            num--;    
            if (num <= 0)
                type = 0;
            break;
        }
    }
    return true;
}

bool StreetMapImpl::getSegmentsThatStartWith(const GeoCoord& gc, vector<StreetSegment>& segs) const
{
    vector<StreetSegment>* s = m_hash->find(gc);
    if (s != nullptr)
    {
        segs = *s; 
        return true;
    }
    else return false;
}

//******************** StreetMap functions ************************************

// These functions simply delegate to StreetMapImpl's functions.
// You probably don't want to change any of this code.

StreetMap::StreetMap()
{
    m_impl = new StreetMapImpl;
}

StreetMap::~StreetMap()
{
    delete m_impl;
}

bool StreetMap::load(string mapFile)
{
    return m_impl->load(mapFile);
}

bool StreetMap::getSegmentsThatStartWith(const GeoCoord& gc, vector<StreetSegment>& segs) const
{
   return m_impl->getSegmentsThatStartWith(gc, segs);
}