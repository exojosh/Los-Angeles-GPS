// ExpandableHashMap.h
// Skeleton for the ExpandableHashMap class template.  You must implement the first six
// member functions.
#include <iostream>

template<typename KeyType, typename ValueType>
class ExpandableHashMap
{
public:
	ExpandableHashMap(double maximumLoadFactor = 0.5);
	~ExpandableHashMap();
	void reset();
	int size() const;
	void associate(const KeyType& key, const ValueType& value);

	  // for a map that can't be modified, return a pointer to const ValueType
	const ValueType* find(const KeyType& key) const;

	  // for a modifiable map, return a pointer to modifiable ValueType
	ValueType* find(const KeyType& key)
	{
		return const_cast<ValueType*>(const_cast<const ExpandableHashMap*>(this)->find(key));
	}

	  // C++11 syntax for preventing copying and assignment
	ExpandableHashMap(const ExpandableHashMap&) = delete;
	ExpandableHashMap& operator=(const ExpandableHashMap&) = delete;

private:
	ExpandableHashMap(double maximumLoadFactor, unsigned int newNumberofBuckets);
	unsigned int getBucketNumber(const KeyType& key) const;
	void ClearAll();
	void exceedMaxLoadFactorProcedure();

	struct KeyPair
	{
		KeyType m_key;
		ValueType m_value;
	};
	struct Node
	{
		KeyPair data;
		Node* next = nullptr;
	};
	Node** m_map;
	double max_loadFactor;
	unsigned int numberofBuckets = 8;
	unsigned int numberofAssociations = 0;
};
template<typename KeyType, typename ValueType>
ExpandableHashMap<typename KeyType, typename ValueType>::ExpandableHashMap(double maximumLoadFactor)
{
	m_map = new Node*[numberofBuckets]();
	max_loadFactor = maximumLoadFactor;
}
template<typename KeyType, typename ValueType>
ExpandableHashMap<typename KeyType, typename ValueType>::ExpandableHashMap(double maximumLoadFactor, unsigned int newNumberofBuckets)
{
	numberofBuckets = newNumberofBuckets;
	m_map = new Node * [numberofBuckets]();
	max_loadFactor = maximumLoadFactor;
}
template<typename KeyType, typename ValueType>
ExpandableHashMap<typename KeyType, typename ValueType>::~ExpandableHashMap()
{
	ClearAll();
}
template<typename KeyType, typename ValueType>
void ExpandableHashMap<typename KeyType, typename ValueType>::reset()
{
	ClearAll();
	numberofBuckets = 8;
	numberofAssociations = 0;
	m_map = new Node*[numberofBuckets]();
}
template<typename KeyType, typename ValueType>
int ExpandableHashMap<typename KeyType, typename ValueType>::size() const
{
	return numberofAssociations;
}
template<typename KeyType, typename ValueType>
void ExpandableHashMap<typename KeyType, typename ValueType>::associate(const KeyType& key, const ValueType& value)
{
	struct Node;
	if ((numberofAssociations / numberofBuckets) > max_loadFactor)
		exceedMaxLoadFactorProcedure();
	ValueType* v = find(key);
	unsigned short int h = getBucketNumber(key);
	if (v == nullptr)
	{
		Node* it = m_map[h];
		if (it == nullptr)
		{
			m_map[h] = new Node;
			m_map[h]->data.m_key = key;
			m_map[h]->data.m_value = value;
		}
		else
		{
			while (it->next != nullptr)
				it = it->next;
			it->next = new Node;
			it->next->data.m_key = key;
			it->next->data.m_value = value;
		}
		numberofAssociations++;
	}
	else
		*v = value;
}
template<typename KeyType, typename ValueType>
const ValueType* ExpandableHashMap<typename KeyType, typename ValueType>::find(const KeyType& key) const
{ //O(1) time on average, but if there's a collision, it'll take an extra amount of steps equal to the amount of collisions. 
	Node* it = m_map[getBucketNumber(key)];  //Check the list at the array element the hash funciton is mapped to
	while (it != nullptr) //Go until you hit nullptr or the key
	{
		if((*it).data.m_key == key)
			return &(*it).data.m_value;
		it = it->next;
	}
	return nullptr;
}
template<typename KeyType, typename ValueType>
void ExpandableHashMap<typename KeyType, typename ValueType>::ClearAll()
{
	for (int i = 0; i < numberofBuckets; i++)
	{
		if (m_map[i] != nullptr)
		{
			Node* p = m_map[i];
			Node* toBeDeleted = m_map[i];
			while (p != nullptr)
			{
				toBeDeleted = p;
				p = p->next;
				delete toBeDeleted;
			}
		}
	}
	delete[] m_map;
}
template<typename KeyType, typename ValueType>
unsigned int ExpandableHashMap<typename KeyType, typename ValueType>::getBucketNumber(const KeyType& key) const
{
	unsigned int hasher(const KeyType & k);
	unsigned int h = hasher(key);
	return h % numberofBuckets;
}
template<typename KeyType, typename ValueType>
void ExpandableHashMap<typename KeyType, typename ValueType>::exceedMaxLoadFactorProcedure()
{
	Node** newmap = new Node*[numberofBuckets*2]();
	numberofBuckets *= 2; //We double the internal number of buckets here so the getBucketBumber function hashes correctly
	for (int i = 0; i < (numberofBuckets / 2); i++)
	{
			Node* it = m_map[i];
			Node* prev = it;
			while (it != nullptr)
			{
				Node* nexxt = it->next;
				Node* newit = newmap[getBucketNumber((*it).data.m_key)];
				if (newit == nullptr)
				{
					newmap[getBucketNumber((*it).data.m_key)] = it;
					it->next = nullptr;
				}
				else
				{
					while (newit != nullptr)
					{
						prev = newit;
						newit = newit->next;
					}
					prev->next = it; //Set the first node whose next pointer is the nullptr to have the new node as the node we wish to insert
					it->next = nullptr;
				}
				prev = it;
				it = nexxt;
			}
	}
	delete[] m_map;
	m_map = newmap;
}