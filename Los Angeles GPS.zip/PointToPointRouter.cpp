#include "provided.h"
#include "ExpandableHashMap.h"
#include <list>
#include <map>
using namespace std;

class PointToPointRouterImpl
{
public:
    PointToPointRouterImpl(const StreetMap* sm);
    ~PointToPointRouterImpl();
    DeliveryResult generatePointToPointRoute(
        const GeoCoord& start,
        const GeoCoord& end,
        list<StreetSegment>& route,
        double& totalDistanceTravelled) const;
private:
    double dist(const GeoCoord& a1, const GeoCoord& a2) const;
    double h(const GeoCoord& current, const GeoCoord& goal) const;
    const StreetMap* m_street;
};

PointToPointRouterImpl::PointToPointRouterImpl(const StreetMap* sm)
{
    m_street = sm;
}

PointToPointRouterImpl::~PointToPointRouterImpl()
{
}

DeliveryResult PointToPointRouterImpl::generatePointToPointRoute(
        const GeoCoord& start,
        const GeoCoord& end,
        list<StreetSegment>& route,
        double& totalDistanceTravelled) const
{
    if (start == end)
    {
        totalDistanceTravelled = 0;
    }
    map<double, const GeoCoord, std::greater<double>> discovered;    
    vector<StreetSegment> connected;
    m_street->getSegmentsThatStartWith(start, connected);
    if (connected.empty())
        return BAD_COORD;
    totalDistanceTravelled = 0;
    ExpandableHashMap<GeoCoord, double> gScore;
    gScore.associate(start, 0);
    ExpandableHashMap<GeoCoord, double> fScore;
    fScore.associate(start, h(start, end));
    discovered.insert(std::pair<double, const GeoCoord>(*fScore.find(start), start));
    ExpandableHashMap<GeoCoord, StreetSegment> locationofPrevCoord;
    while (!discovered.empty())
    {
        const GeoCoord current = discovered.begin()->second;
        discovered.erase(discovered.begin());
        if (current == end)
        {
            list<StreetSegment> finalroute;
            finalroute.push_front(*locationofPrevCoord.find(end));
            totalDistanceTravelled += distanceEarthMiles(finalroute.front().start, finalroute.front().end);
            while (finalroute.front().start != start)
            {
                finalroute.push_front(*locationofPrevCoord.find(finalroute.front().start));
                totalDistanceTravelled += distanceEarthMiles(finalroute.front().start, finalroute.front().end);
            }
            route = finalroute;
            return DELIVERY_SUCCESS;
        }
        m_street->getSegmentsThatStartWith(current, connected);
        while (!connected.empty())
        {
            const GeoCoord & neighbor = connected.back().end;
            double potentialgScore = *gScore.find(current) + dist(current, neighbor);
            double neighborgScore = 999999.;
            if (gScore.find(neighbor) != nullptr)
                neighborgScore = *gScore.find(neighbor);
            if (potentialgScore < neighborgScore)
            {
                   locationofPrevCoord.associate(neighbor, connected.back());
                   gScore.associate(neighbor, potentialgScore);
                   fScore.associate(neighbor, neighborgScore + h(neighbor, end)); 
                   discovered.insert(std::pair<double, const GeoCoord&>(*fScore.find(neighbor), neighbor));
            }
            connected.pop_back();
        }
    }
    return NO_ROUTE;
}

double PointToPointRouterImpl::dist(const GeoCoord& a1, const GeoCoord& a2) const
{
    return 66.3419*sqrt((a1.latitude - a2.latitude) * (a1.latitude - a2.latitude) + (a1.longitude - a2.longitude) * (a1.longitude - a2.longitude));
} //the above decimal is the approximate amount of miles between a degree of longitude in los angeles area.

double PointToPointRouterImpl::h(const GeoCoord& current, const GeoCoord& goal) const
{
    return distanceEarthMiles(current, goal);
}

//******************** PointToPointRouter functions ***************************

// These functions simply delegate to PointToPointRouterImpl's functions.
// You probably don't want to change any of this code.

PointToPointRouter::PointToPointRouter(const StreetMap* sm)
{
    m_impl = new PointToPointRouterImpl(sm);
}

PointToPointRouter::~PointToPointRouter()
{
    delete m_impl;
}

DeliveryResult PointToPointRouter::generatePointToPointRoute(
        const GeoCoord& start,
        const GeoCoord& end,
        list<StreetSegment>& route,
        double& totalDistanceTravelled) const
{
    return m_impl->generatePointToPointRoute(start, end, route, totalDistanceTravelled);
}