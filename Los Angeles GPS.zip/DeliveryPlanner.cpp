#include "provided.h"
#include <vector>
#include <queue>
using namespace std;

class DeliveryPlannerImpl
{
public:
    DeliveryPlannerImpl(const StreetMap* sm);
    ~DeliveryPlannerImpl();
    DeliveryResult generateDeliveryPlan(
        const GeoCoord& depot,
        const vector<DeliveryRequest>& deliveries,
        vector<DeliveryCommand>& commands,
        double& totalDistanceTravelled) const;
private:
    string calcCardinalDirection(StreetSegment* s) const;
    string calcTurnDirection(StreetSegment* a1, StreetSegment* a2) const;
    const StreetMap* m_street;
};

DeliveryPlannerImpl::DeliveryPlannerImpl(const StreetMap* sm)
{
    m_street = sm;
}

DeliveryPlannerImpl::~DeliveryPlannerImpl()
{
}

DeliveryResult DeliveryPlannerImpl::generateDeliveryPlan(
    const GeoCoord& depot,
    const vector<DeliveryRequest>& deliveries,
    vector<DeliveryCommand>& commands,
    double& totalDistanceTravelled) const
{
    DeliveryOptimizer* s = new DeliveryOptimizer(m_street);
    double old = 0, final = 0;
    vector<DeliveryRequest> newdeliveries = deliveries;
    s->optimizeDeliveryOrder(depot, newdeliveries, old, final);
    delete s;
    totalDistanceTravelled = 0;
    PointToPointRouter* t = new PointToPointRouter(m_street);
    list<StreetSegment> li, finallist;
    vector<StreetSegment> testing;
    m_street->getSegmentsThatStartWith(depot, testing);
    if (testing.empty())
            return BAD_COORD;
    if (newdeliveries.empty())
        return NO_ROUTE;
    t->generatePointToPointRoute(depot, newdeliveries.begin()->location, li, old); //Need a seperate case since 
    finallist.splice(finallist.end(), li);
    totalDistanceTravelled += old;
    std::vector<DeliveryRequest>::iterator  it= newdeliveries.begin();
    it++;
    while (it != newdeliveries.end())
    {
        t->generatePointToPointRoute(finallist.back().end, it->location, li, old);
        totalDistanceTravelled += old;
        finallist.splice(finallist.end(), li);
        it++;
    }
    it--;
    t->generatePointToPointRoute(it->location, depot, li, old);
    delete t;
    totalDistanceTravelled += old;
    finallist.splice(finallist.end(), li);
    GeoCoord* currentLoc;
    StreetSegment* prev = nullptr;
    StreetSegment* curr = nullptr;
    double proceedDistance = 0;
    std::list<StreetSegment>::iterator finalit = finallist.begin();
    newdeliveries.push_back(DeliveryRequest("depot", depot));
    while (finalit != finallist.end())
    {
        currentLoc = &(*finalit).end;
        prev = curr;
        curr = &(*finalit);
        finalit++;
        proceedDistance += distanceEarthMiles(curr->start, curr->end);
        if (prev == nullptr)
            continue;
        string str = calcTurnDirection(curr, prev);
        bool checkifProceedingonDiffStreet = true;
        bool nameisDifferent = false;
        if (curr->name != prev->name)
            nameisDifferent = true;
        if (str != "proceed" && nameisDifferent)
        {
            proceedDistance -= distanceEarthMiles(curr->start, curr->end);
            DeliveryCommand contin, turn;
            contin.initAsProceedCommand(calcCardinalDirection(prev), prev->name, proceedDistance);
            commands.push_back(contin);
            proceedDistance = 0;
            turn.initAsTurnCommand(str, curr->name);
            commands.push_back(turn);
            proceedDistance += distanceEarthMiles(curr->start, curr->end);
            checkifProceedingonDiffStreet = false;
        }
        if (*currentLoc == newdeliveries.front().location)
        {
            DeliveryCommand contin, deliv;
            contin.initAsProceedCommand(calcCardinalDirection(prev), curr->name, proceedDistance);
            commands.push_back(contin);
            proceedDistance = 0;
            deliv.initAsDeliverCommand(newdeliveries.front().item);
            if (newdeliveries.front().item != "depot")
                commands.push_back(deliv);
            newdeliveries.erase(newdeliveries.begin());
            continue;
        }
        else if (checkifProceedingonDiffStreet && nameisDifferent)
        {
            DeliveryCommand contin;
            contin.initAsProceedCommand(calcCardinalDirection(curr), curr->name, proceedDistance);
            commands.push_back(contin);
            proceedDistance = 0;
        }
    }
    return DELIVERY_SUCCESS;
}

string DeliveryPlannerImpl::calcCardinalDirection(StreetSegment* s) const
{
    double angle = angleOfLine(*s);
    if (0 <= angle && angle <= 22.5)
        return "east";
    else if (22.5 < angle && angle <= 67.5)
        return "northeast";
    else if (67.5 < angle && angle <= 112.5)
        return "north";
    else if (112.5 < angle && angle <= 157.5)
        return "northwest";
    else if (157.5 < angle && angle <= 202.5)
        return "west";
    else if (202.5 < angle && angle <= 247.5)
        return "southwest";
    else if (247.5 < angle && angle <= 292.5)
        return "south";
    else if (292.5 < angle && angle <= 337.5)
        return "southeast";
    else return "east";
}

string DeliveryPlannerImpl::calcTurnDirection(StreetSegment* a1, StreetSegment* a2) const
{
    double angle = angleBetween2Lines(*a1, *a2);
    if ((0 <= angle && angle < 1) || (359 <= angle && angle < 360))
        return "proceed";
    else if (1 <= angle && angle <= 180)
        return "right";
    else if (180 <= angle && angle <= 359)
        return "left";
    else return "ERROR";
}

//******************** DeliveryPlanner functions ******************************

// These functions simply delegate to DeliveryPlannerImpl's functions.
// You probably don't want to change any of this code.

DeliveryPlanner::DeliveryPlanner(const StreetMap* sm)
{
    m_impl = new DeliveryPlannerImpl(sm);
}

DeliveryPlanner::~DeliveryPlanner()
{
    delete m_impl;
}

DeliveryResult DeliveryPlanner::generateDeliveryPlan(
    const GeoCoord& depot,
    const vector<DeliveryRequest>& deliveries,
    vector<DeliveryCommand>& commands,
    double& totalDistanceTravelled) const
{
    return m_impl->generateDeliveryPlan(depot, deliveries, commands, totalDistanceTravelled);
}