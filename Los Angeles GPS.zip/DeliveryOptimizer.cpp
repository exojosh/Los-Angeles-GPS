#include "provided.h"
#include <vector>
#include <map>

#include <iostream>

using namespace std;

class DeliveryOptimizerImpl
{
public:
    DeliveryOptimizerImpl(const StreetMap* sm);
    ~DeliveryOptimizerImpl();
    void optimizeDeliveryOrder(
        const GeoCoord& depot,
        vector<DeliveryRequest>& deliveries,
        double& oldCrowDistance,
        double& newCrowDistance) const;
private:
    struct GraphNode
    {

        int first = -1;
        int second = -1;
        bool insert(int s)
        {
            if (first != -1 && second != -1)
                return false;
            if (first == -1)
                first = s;
            else second = s;
            return true;
        }
        bool hasRoom()
        {
            if (first == -1 || second == -1)
                return true;
            else return false;
        }
        int getUnique(int notThis)
        {
            if (first != notThis)
                return first;
            else return second;
        }
        bool isEmpty()
        {
            bool result = (first == -1 && second == -1);
            return result;
        }
    };
    double calculateCrowsDistance(vector<DeliveryRequest>& deliveries, const GeoCoord& depot) const;
};

DeliveryOptimizerImpl::DeliveryOptimizerImpl(const StreetMap* sm)
{
}

DeliveryOptimizerImpl::~DeliveryOptimizerImpl()
{
}

void DeliveryOptimizerImpl::optimizeDeliveryOrder(
    const GeoCoord& depot,
    vector<DeliveryRequest>& deliveries,
    double& oldCrowDistance,
    double& newCrowDistance) const
{
    oldCrowDistance = calculateCrowsDistance(deliveries, depot);
    if (deliveries.size() <= 2)
        return;
    map< double, std::pair<int, int>, std::greater<double>> crowsDist;
    for (int i = deliveries.size() - 1; i >= 0; i--)
    {
        for (int j = deliveries.size() - 1; j >= 0; j--)
            if (j <= i)
                continue;
            else
            {
                std::pair<int, int> temp  = { i, j };
                crowsDist.insert(std::pair< double, std::pair<int, int>>(distanceEarthMiles(deliveries[i].location, deliveries[j].location), temp));
                cout << i << ", " << j << ":  " << distanceEarthMiles(deliveries[i].location, deliveries[j].location) << "\n";
            }
        std::pair<int, int> temp = { i, deliveries.size()};
        crowsDist.insert(std::pair< double, std::pair<int, int>>(distanceEarthMiles(deliveries[i].location, GeoCoord(depot.latitudeText, depot.longitudeText)), temp));
    } //Calculate upper triangular matrix of all vertex distances and sort by min distance O((n+1/2)^2)

    vector<GraphNode> nodes(deliveries.size() + 1 ); //for  0 <= i < deliveries. size(), nodes[i] is corresponding position in original vector while i = deliveries.size() is the depot.
    int a = crowsDist.begin()->second.first, b = crowsDist.begin()->second.second;
    nodes[a].insert(b);
    nodes[b].insert(a);
    nodes[a].hasRoom();
    nodes[b].hasRoom();
    crowsDist.erase(crowsDist.begin());
    int edgesLeft = deliveries.size() ; //Total nodes = total edges = deliveries.size() + 1, and we just added one so use deliveries.size()
    while (edgesLeft > 0)
    {

        a = crowsDist.begin()->second.first, b = crowsDist.begin()->second.second;
        if (nodes[a].hasRoom() && nodes[b].hasRoom()) //Both nodes of next shortest segment must be of degree <=1
        {
            bool empty = false;
            if (edgesLeft == 2)
            {
                for (int i = 0; i <= deliveries.size(); i++)
                {
                    if (i == a || i == b)
                        continue;
                    if (nodes[i].isEmpty())
                        empty = true;
                }
            }
            if (!empty)
            {
                nodes[a].insert(b);
                nodes[b].insert(a);
                edgesLeft--;
            }
        }
            crowsDist.erase(crowsDist.begin());
        } //Creates Hamiltonian cycle by connecting segments in order with least distance that have free connections, O(n) maximum time.
        a = nodes[deliveries.size()].first; //This will be the first node we visit from the depot.
        b = nodes[a].getUnique(deliveries.size());
        int dummy = 0;
        vector<DeliveryRequest> final;
        final.push_back(deliveries[a]);
        while (b != deliveries.size())
        {
            final.push_back(deliveries[b]);
            a = nodes[b].getUnique(a);
            dummy = b;
            b = a;
            a = dummy;
        }
        newCrowDistance = calculateCrowsDistance(final, depot);
        deliveries = final;
} //Biggest flaw of this algorithm is it doesn't allow visiting a same node twice even if optimal. All routes are hamiltonion cycles.
double DeliveryOptimizerImpl::calculateCrowsDistance(vector<DeliveryRequest>& deliveries, const GeoCoord& depot) const
{
    double result = 0;
    result += distanceEarthMiles(deliveries[0].location, depot);
    for (int i = 1; i < deliveries.size(); i++)
        result += distanceEarthMiles(deliveries[i].location, deliveries[i - 1].location);
    result += distanceEarthMiles(deliveries[deliveries.size() - 1].location, depot);
    return result;
}

//******************** DeliveryOptimizer functions ****************************

// These functions simply delegate to DeliveryOptimizerImpl's functions.
// You probably don't want to change any of this code.

DeliveryOptimizer::DeliveryOptimizer(const StreetMap* sm)
{
    m_impl = new DeliveryOptimizerImpl(sm);
}

DeliveryOptimizer::~DeliveryOptimizer()
{
    delete m_impl;
}

void DeliveryOptimizer::optimizeDeliveryOrder(
        const GeoCoord& depot,
        vector<DeliveryRequest>& deliveries,
        double& oldCrowDistance,
        double& newCrowDistance) const
{
    return m_impl->optimizeDeliveryOrder(depot, deliveries, oldCrowDistance, newCrowDistance);
}